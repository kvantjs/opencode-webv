# Animações do Agente de IA — Pacote de Integração

Este pacote separa as animações visuais encontradas no frontend em módulos independentes. Cada pasta contém o CSS exato ou equivalente extraído do comportamento original, os estados esperados, as dependências e uma orientação de integração.

## Módulos

1. `01-working-pulse`: ponto pulsante que indica processamento ativo.
2. `02-working-rail`: rail de trabalho com entrada, tempo e estado ativo.
3. `03-working-label-swap`: troca animada de labels de atividade.
4. `04-live-activity-shimmer`: shimmer em texto de atividade em streaming.
5. `05-reasoning-live`: reasoning/pensamento expansível e atualizado em streaming.
6. `06-subagent-pulse`: indicador de subagente trabalhando.
7. `07-settling-and-stopped`: finalização suave e estado interrompido.
8. `08-design-beam`: feixe colorido de modo ativo; é um efeito separado do pensamento.
9. `09-onboarding-preview`: animação demonstrativa; não representa estado real do agente.
10. `10-effort-ladder`: configuração visual do nível de raciocínio, não atividade em tempo real.
11. `11-reduced-motion`: regras de acessibilidade para desativar movimento.

## Fluxo de estados recomendado

```text
idle
  -> turn.started
  -> working + activeTurn
  -> reasoning/tool/message streaming
  -> label e conteúdo atualizados
  -> turn.completed ou interrupted
  -> settled/stopped
  -> idle
```

## Contrato mínimo de estado

```ts
type AgentActivityState = {
  running: boolean
  activeTurn?: { id: string; startedAt: number }
  phase?: 'working' | 'searching' | 'reasoning' | 'tool' | 'writing' | 'stopped'
  label?: string
  reasoningText?: string
  reasoningLive?: boolean
  stopped?: boolean
}
```

## Ordem de implementação

Para adicionar somente a animação principal ao agente, use nesta ordem:

1. `01-working-pulse`
2. `02-working-rail`
3. `03-working-label-swap`
4. `05-reasoning-live`
5. `07-settling-and-stopped`
6. `11-reduced-motion`

Adicione `06-subagent-pulse` apenas se houver agentes paralelos. Use `08-design-beam` somente para um modo visual ativo, nunca como substituto do estado semântico de pensamento.

## Tokens mínimos

```css
:root {
  --text: #EDEDED;
  --text-2: #A3A3A3;
  --text-3: #8A8A8A;
  --surface: #1A1A1A;
  --surface-2: #222222;
  --line: #262626;
  --running: #D4D4D4;
  --error: #E5687A;
  --success: #6FBF8E;
  --r-pill: 999px;
  --r-md: 8px;
  --t-sm: 12.5px;
  --font-ui: system-ui, sans-serif;
  --font-mono: ui-monospace, monospace;
  --ease-out: cubic-bezier(0.23, 1, 0.32, 1);
  --ease-in-out: cubic-bezier(0.77, 0, 0.175, 1);
  --dur-fast: 180ms;
  --dur-slow: 260ms;
}
```

Para tema claro, substitua `--text`, `--text-2`, `--text-3`, `--surface`, `--surface-2` e estados por seus equivalentes claros. Não altere a lógica dos estados.

## Regra importante

As animações devem comunicar estado sem depender apenas de cor. Sempre combine movimento com texto, ícone, duração ou estado acessível. O pulso comunica “ainda está trabalhando”; o texto comunica o que está fazendo; o reasoning comunica o conteúdo do pensamento; o estado final comunica conclusão ou interrupção.
