# 05 — Reasoning Live

Estado de pensamento/raciocínio do agente. O cabeçalho é colapsável e o conteúdo pode ser atualizado enquanto o item está em streaming.

## Contrato de dados

```ts
type ReasoningState = {
  text: string
  live: boolean
  status: 'started' | 'completed'
  createdAt: number
}
```

## React

```tsx
function ReasoningBlock({ state, expanded, onToggle }) {
  const label = state.live ? liveThoughtLabel(state.createdAt) : thoughtHeadline(state.text)

  return (
    <div className={`agent-reasoning ${state.live ? 'is-live' : ''}`}>
      <button
        type="button"
        className="agent-reasoning__row"
        aria-expanded={expanded}
        onClick={onToggle}
      >
        <span className="agent-reasoning__glyph" aria-hidden="true">🧠</span>
        <span className="agent-reasoning__label">{label}</span>
        <span className="agent-reasoning__chevron" aria-hidden="true">›</span>
      </button>

      <div className={`agent-reasoning__reveal${expanded ? ' is-open' : ''}`}>
        <div className="agent-reasoning__content">
          {state.text}
        </div>
      </div>
    </div>
  )
}
```

Substitua o texto puro pelo renderer Markdown da sua aplicação. Durante streaming, atualize apenas o conteúdo e preserve o container.
