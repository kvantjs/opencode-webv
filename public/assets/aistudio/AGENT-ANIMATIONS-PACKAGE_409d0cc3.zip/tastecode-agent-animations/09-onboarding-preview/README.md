# 09 — Onboarding Preview

Este módulo representa uma simulação visual de atividades do agente: exploração, edição, diff e resposta. Ele é demonstrativo, com conteúdo fixo e tempos próprios. Não conecte esse módulo ao estado real de produção sem substituir os dados simulados.

Use somente em onboarding, marketing interno ou preview de produto.
