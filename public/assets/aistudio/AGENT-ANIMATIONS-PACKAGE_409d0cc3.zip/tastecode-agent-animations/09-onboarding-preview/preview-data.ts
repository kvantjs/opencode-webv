export const previewActivities = [
  { icon: 'search', label: 'Explored 3 files' },
  { icon: 'pencil', label: 'Edited a file' },
] as const
