# 08 — Design Beam

Efeito de feixe colorido para indicar um modo visual ativo. Este efeito não deve substituir `working`, `thinking` ou `reasoning`, porque não é semântico por si só.

Ative com `data-active` e remova com `data-fading`. O CSS completo está separado abaixo para copiar como um módulo independente.
