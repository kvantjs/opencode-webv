# 02 — Working Rail

Container persistente do estado de trabalho. Mantenha uma única instância montada durante o turno para que o pulso não reinicie a cada atualização de streaming.

## HTML/React

```tsx
function WorkingRail({ label, startedAt }) {
  return (
    <div className="agent-working-rail">
      <div className="agent-working-rail__summary">
        <WorkingPulse />
        <WorkingLabel label={label} startedAt={startedAt} />
      </div>
    </div>
  )
}
```
