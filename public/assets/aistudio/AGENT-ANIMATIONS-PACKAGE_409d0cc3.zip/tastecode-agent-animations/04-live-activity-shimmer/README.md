# 04 — Live Activity Shimmer

Shimmer aplicado ao texto enquanto uma atividade está viva ou recebendo eventos de streaming. Use com moderação: ele deve aparecer somente no label ativo.
