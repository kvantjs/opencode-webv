# 03 — Working Label Swap

Troca animada do texto de atividade. Use quando o agente muda de fase, por exemplo `Working` → `Searching` → `Editing`.

O label anterior permanece por 480ms para que a troca não pareça uma substituição abrupta.

```tsx
function WorkingLabel({ label, previousLabel, startedAt }) {
  return (
    <span className="agent-working-label-swap" aria-live="polite" aria-atomic="true">
      {previousLabel ? (
        <span className="agent-working-status-previous" aria-hidden="true">
          <span>{previousLabel}</span>
          <WorkingTimer startedAt={startedAt} />
        </span>
      ) : null}
      <span className={`agent-working-status${previousLabel ? ' is-entering' : ''}`}>
        <span>{label}</span>
        <WorkingTimer startedAt={startedAt} />
      </span>
    </span>
  )
}
```
