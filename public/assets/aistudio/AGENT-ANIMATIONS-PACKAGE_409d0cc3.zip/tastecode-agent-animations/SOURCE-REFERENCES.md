# Referências exatas

Os arquivos `source-reference-*` são cópias dos arquivos originais do frontend analisado. Eles preservam nomes de classes, comentários e contexto original. Os arquivos sem esse prefixo são módulos portáteis preparados para integração em outra aplicação.

As referências não devem ser importadas cegamente: adapte apenas o estado, nomes de classes e renderer da aplicação destino, preservando os tempos, keyframes e regras documentadas.
