# 07 — Settling and Stopped

Transição curta quando o agente termina ou é interrompido. Use `is-settling` em um item que acabou de sair de `working` e `is-stopped` quando o usuário interromper o turno.
