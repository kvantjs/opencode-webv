# 06 — Subagent Pulse

Indicador de subagente em execução. É deliberadamente mais discreto que o pulso principal: anima somente a opacidade.
