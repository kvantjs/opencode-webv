# 11 — Reduced Motion

Inclua estas regras globalmente. O estado deve continuar compreensível quando toda animação for desativada.
