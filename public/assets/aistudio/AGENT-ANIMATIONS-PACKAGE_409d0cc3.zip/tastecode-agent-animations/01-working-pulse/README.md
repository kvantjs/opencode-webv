# 01 — Working Pulse

Indicador principal de que o agente está processando. Use dentro de um label como `Working`, `Searching` ou `Editing`.

## Ativação

Renderize o elemento somente enquanto `running === true`. Ao finalizar, remova a classe ou troque pelo estado final.

## HTML/React

```tsx
function WorkingPulse() {
  return (
    <span className="agent-activity__glyph" aria-hidden="true">
      <span className="agent-activity__pulse" />
    </span>
  )
}
```
