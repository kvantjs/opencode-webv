# 10 — Effort Ladder

Controle visual de nível de esforço/raciocínio. Representa uma configuração do modelo, não o estado de pensamento em tempo real.
